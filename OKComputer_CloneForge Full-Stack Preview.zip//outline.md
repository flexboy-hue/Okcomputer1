# CloneForge Project Outline

## Project Overview
CloneForge is a comprehensive full-stack web application that enables users to clone, customize, and generate websites through an intuitive interface. The application provides a complete workflow from source URL input to final export, including image generation and WordPress integration capabilities.

## File Structure

```
/mnt/okcomputer/output/
├── index.html                 # Home page with hero section and CTA
├── generator.html             # Website generation form and controls
├── preview.html               # Generated site preview and export options
├── admin.html                 # Project dashboard and management
├── main.js                    # Core JavaScript functionality
├── server.js                  # Node.js Express backend server
├── database.js                # SQLite database configuration
├── package.json               # Node.js dependencies and scripts
├── README.md                  # Complete setup and usage instructions
├── design.md                  # Visual design system documentation
├── interaction.md             # User interaction design specifications
├── outline.md                 # This project structure document
├── resources/                 # Static assets directory
│   ├── images/               # UI images and icons
│   ├── templates/            # HTML/CSS templates for generation
│   └── samples/              # Demo project files
├── projects/                 # Generated project storage
│   ├── demo-portfolio/       # Sample portfolio project
│   ├── demo-ecommerce/       # Sample e-commerce project
│   └── [project-id]/         # Dynamic project folders
└── export/                   # Export functionality
    ├── wordpress/            # WordPress export templates
    └── templates/            # Export template files
```

## Page Breakdown

### 1. index.html - Home Page
**Purpose**: Landing page with hero section and primary CTA
**Key Features**:
- Animated hero background with particle system
- Feature showcase cards with hover effects
- Prominent "Generate" CTA button
- Navigation to other pages
- Dark mode design with purple gradients

**Sections**:
- Navigation header with blur backdrop
- Hero area with tagline and CTA
- Feature grid (Clone, Customize, Export)
- Technology showcase
- Footer with minimal copyright

### 2. generator.html - Website Generator
**Purpose**: Main interface for website cloning and generation
**Key Features**:
- URL input field with validation
- Screenshot upload area (drag & drop)
- Style preset selection (Portfolio, E-commerce, Blog, Landing)
- Notes textarea for custom instructions
- Real-time preview generation
- Progress indicators with animations

**Sections**:
- Compact navigation
- Generation form with multiple steps
- Style selector grid
- Preview area
- Export options sidebar

### 3. preview.html - Site Preview
**Purpose**: Display and interact with generated websites
**Key Features**:
- Device preview toggles (Desktop/Tablet/Mobile)
- Live iframe preview of generated site
- Code viewer with syntax highlighting
- Download and export options
- Project metadata display

**Sections**:
- Preview controls toolbar
- Device frame with generated content
- Code tabs (HTML/CSS/JS)
- Export panel with options

### 4. admin.html - Project Dashboard
**Purpose**: Manage and organize generated projects
**Key Features**:
- Project grid with thumbnails
- Search and filter functionality
- Project status indicators
- Bulk operations
- Analytics stub display

**Sections**:
- Dashboard header with stats
- Project grid/list view toggle
- Filter sidebar
- Project detail modals

## Backend Architecture

### server.js - Express Server
**Framework**: Node.js + Express
**Database**: SQLite3 with Sequelize ORM
**Key Endpoints**:
- `POST /api/generate` - Process website generation
- `GET /api/projects` - List all projects
- `GET /api/projects/:id` - Get specific project details
- `POST /api/preview/:id` - Generate preview
- `POST /api/export/:id` - Export project files
- `POST /api/images/generate` - Generate images

**Features**:
- Static file serving
- API routing
- Database integration
- File upload handling
- CORS configuration
- Error handling

### database.js - Database Layer
**Database**: SQLite3 (file-based)
**ORM**: Sequelize
**Models**:
- `Project` - Generated websites
- `User` - User accounts (stub)
- `Image` - Generated images
- `Template` - Style templates

**Features**:
- Database initialization
- Model definitions
- Relationship mapping
- Seed data insertion

## Core Functionality

### Website Generation Engine
**Process**:
1. URL input validation and processing
2. Content scraping and analysis (simulated)
3. Template selection and customization
4. HTML/CSS/JS generation
5. Asset optimization and organization
6. Project storage and indexing

**Templates**:
- Portfolio template with gallery and contact forms
- E-commerce template with product grids and cart
- Blog template with post listings and categories
- Landing page template with hero sections and CTAs

### Image Generation Stub
**Functionality**:
- Text prompt input interface
- Style tag selection
- Size and format options
- Procedural image generation (SVG/Canvas)
- Image storage and management
- Integration with website templates

**Generation Methods**:
- SVG pattern generation
- Canvas-based graphics
- Color palette generation
- Geometric shape compositions

### WordPress Export Feature
**Components**:
- Elementor template mapping
- WordPress theme structure
- Plugin compatibility stubs
- XML export format
- Installation guide generation

**Export Package**:
- Theme files (PHP, CSS, JS)
- Template parts
- Widget configurations
- Demo content
- Documentation

## Technical Stack

### Frontend Technologies
- **HTML5**: Semantic markup and accessibility
- **CSS3**: Grid, Flexbox, animations, custom properties
- **JavaScript ES6+**: Modern syntax, modules, async/await
- **Anime.js**: Smooth animations and transitions
- **ECharts.js**: Data visualization and charts
- **PIXI.js**: Interactive graphics and particle effects
- **Shader-park**: Background visual effects

### Backend Technologies
- **Node.js**: JavaScript runtime environment
- **Express.js**: Web framework and routing
- **SQLite3**: Lightweight database
- **Sequelize**: ORM for database operations
- **Multer**: File upload handling
- **CORS**: Cross-origin resource sharing
- **Helmet**: Security middleware

### Development Tools
- **npm**: Package management
- **Nodemon**: Development server with auto-restart
- **ESLint**: Code linting and quality
- **Prettier**: Code formatting
- **Git**: Version control

## Sample Projects

### Demo Portfolio
**Features**:
- Professional landing page
- Project gallery with filters
- Contact form with validation
- Responsive design
- Dark/light mode toggle

### Demo E-commerce
**Features**:
- Product catalog with categories
- Shopping cart functionality
- User authentication stub
- Payment integration stubs
- Order management interface

## Export and Deployment

### Local Development
- **Server**: `npm run dev` - Starts development server
- **Database**: Auto-initializes on first run
- **File Watching**: Automatic restart on changes
- **Port**: Default 3000 (configurable)

### Production Considerations
- **Static Hosting**: Can be deployed to any static host
- **Database**: SQLite file can be persisted
- **Assets**: Optimized and compressed
- **Security**: Input validation and sanitization

## User Experience Flow

1. **Landing** → User arrives at home page with animated hero
2. **Generate** → Click CTA to access generator page
3. **Input** → Enter URL, upload screenshots, select style
4. **Process** → Watch generation progress with animations
5. **Preview** → View generated site in multiple device modes
6. **Export** → Download code or WordPress package
7. **Manage** → Access dashboard to view all projects

This comprehensive structure ensures CloneForge delivers a complete, professional-grade website cloning and generation experience while maintaining code quality and user experience standards.