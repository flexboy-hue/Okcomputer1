// CloneForge Main JavaScript
class CloneForge {
    constructor() {
        this.currentPage = this.getCurrentPage();
        this.apiBase = '/api';
        this.init();
    }

    getCurrentPage() {
        const path = window.location.pathname;
        if (path.includes('generator')) return 'generator';
        if (path.includes('preview')) return 'preview';
        if (path.includes('admin')) return 'admin';
        return 'home';
    }

    init() {
        this.initializeAnimations();
        this.initializeNavigation();
        
        // Page-specific initialization
        switch (this.currentPage) {
            case 'home':
                this.initHome();
                break;
            case 'generator':
                this.initGenerator();
                break;
            case 'preview':
                this.initPreview();
                break;
            case 'admin':
                this.initAdmin();
                break;
        }
    }

    initializeAnimations() {
        // Initialize Anime.js animations
        if (typeof anime !== 'undefined') {
            this.setupScrollAnimations();
            this.setupHoverEffects();
        }

        // Initialize particle background if PIXI is available
        if (typeof PIXI !== 'undefined') {
            this.initParticleBackground();
        }
    }

    initializeNavigation() {
        // Mobile menu toggle
        const mobileToggle = document.querySelector('.mobile-toggle');
        const nav = document.querySelector('nav ul');
        
        if (mobileToggle && nav) {
            mobileToggle.addEventListener('click', () => {
                nav.classList.toggle('active');
            });
        }

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(link.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    setupScrollAnimations() {
        // Stagger animation for cards
        const cards = document.querySelectorAll('.feature-card, .project-card, .product-card');
        if (cards.length > 0) {
            anime({
                targets: cards,
                translateY: [50, 0],
                opacity: [0, 1],
                delay: anime.stagger(100),
                duration: 800,
                easing: 'easeOutQuart'
            });
        }

        // Hero text animation
        const heroTitle = document.querySelector('.hero h1');
        const heroSubtitle = document.querySelector('.hero p');
        const heroButton = document.querySelector('.hero .cta');

        if (heroTitle) {
            anime({
                targets: heroTitle,
                translateY: [100, 0],
                opacity: [0, 1],
                duration: 1000,
                delay: 300,
                easing: 'easeOutQuart'
            });
        }

        if (heroSubtitle) {
            anime({
                targets: heroSubtitle,
                translateY: [50, 0],
                opacity: [0, 1],
                duration: 800,
                delay: 600,
                easing: 'easeOutQuart'
            });
        }

        if (heroButton) {
            anime({
                targets: heroButton,
                scale: [0.8, 1],
                opacity: [0, 1],
                duration: 600,
                delay: 900,
                easing: 'easeOutBack'
            });
        }
    }

    setupHoverEffects() {
        // Button hover effects
        const buttons = document.querySelectorAll('.cta, button');
        buttons.forEach(button => {
            button.addEventListener('mouseenter', () => {
                anime({
                    targets: button,
                    scale: 1.05,
                    duration: 200,
                    easing: 'easeOutQuart'
                });
            });

            button.addEventListener('mouseleave', () => {
                anime({
                    targets: button,
                    scale: 1,
                    duration: 200,
                    easing: 'easeOutQuart'
                });
            });
        });

        // Card hover effects
        const cards = document.querySelectorAll('.feature-card, .project-card, .product-card');
        cards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                anime({
                    targets: card,
                    translateY: -10,
                    duration: 300,
                    easing: 'easeOutQuart'
                });
            });

            card.addEventListener('mouseleave', () => {
                anime({
                    targets: card,
                    translateY: 0,
                    duration: 300,
                    easing: 'easeOutQuart'
                });
            });
        });
    }

    initParticleBackground() {
        const canvas = document.getElementById('particle-canvas');
        if (!canvas) return;

        const app = new PIXI.Application({
            view: canvas,
            width: window.innerWidth,
            height: window.innerHeight,
            transparent: true,
            antialias: true
        });

        // Create particle container
        const particles = new PIXI.Container();
        app.stage.addChild(particles);

        // Create particles
        for (let i = 0; i < 50; i++) {
            const particle = new PIXI.Graphics();
            particle.beginFill(0x6366f1, 0.3);
            particle.drawCircle(0, 0, Math.random() * 3 + 1);
            particle.endFill();

            particle.x = Math.random() * app.screen.width;
            particle.y = Math.random() * app.screen.height;
            particle.vx = (Math.random() - 0.5) * 2;
            particle.vy = (Math.random() - 0.5) * 2;

            particles.addChild(particle);
        }

        // Animate particles
        app.ticker.add(() => {
            particles.children.forEach(particle => {
                particle.x += particle.vx;
                particle.y += particle.vy;

                if (particle.x < 0 || particle.x > app.screen.width) particle.vx *= -1;
                if (particle.y < 0 || particle.y > app.screen.height) particle.vy *= -1;
            });
        });

        // Resize handler
        window.addEventListener('resize', () => {
            app.renderer.resize(window.innerWidth, window.innerHeight);
        });
    }

    // Home page initialization
    initHome() {
        // Feature cards interaction
        const featureCards = document.querySelectorAll('.feature-card');
        featureCards.forEach((card, index) => {
            card.addEventListener('click', () => {
                this.showFeatureDetails(index);
            });
        });

        // CTA button
        const ctaButton = document.querySelector('.hero .cta');
        if (ctaButton) {
            ctaButton.addEventListener('click', () => {
                window.location.href = '/generator';
            });
        }
    }

    showFeatureDetails(index) {
        const features = [
            'Clone any website with our advanced scraping technology',
            'Customize every aspect with our intuitive editor',
            'Export to multiple formats including WordPress'
        ];

        // Show modal or tooltip with feature details
        this.showNotification(features[index] || 'Feature information');
    }

    // Generator page initialization
    initGenerator() {
        this.setupFormValidation();
        this.setupFileUpload();
        this.setupStyleSelection();
        this.setupGenerationProcess();
    }

    setupFormValidation() {
        const urlInput = document.getElementById('url-input');
        const form = document.getElementById('generator-form');

        if (urlInput) {
            urlInput.addEventListener('input', (e) => {
                this.validateUrl(e.target.value);
            });
        }

        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleGeneration();
            });
        }
    }

    validateUrl(url) {
        const urlRegex = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
        const urlInput = document.getElementById('url-input');
        const feedback = document.getElementById('url-feedback');

        if (url && !urlRegex.test(url)) {
            urlInput.classList.add('invalid');
            if (feedback) feedback.textContent = 'Please enter a valid URL';
            return false;
        } else {
            urlInput.classList.remove('invalid');
            if (feedback) feedback.textContent = '';
            return true;
        }
    }

    setupFileUpload() {
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('screenshot-input');

        if (!dropZone || !fileInput) return;

        // Drag and drop handlers
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('drag-over');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('drag-over');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            const files = Array.from(e.dataTransfer.files);
            this.handleFileUpload(files);
        });

        // Click to upload
        dropZone.addEventListener('click', () => {
            fileInput.click();
        });

        fileInput.addEventListener('change', (e) => {
            const files = Array.from(e.target.files);
            this.handleFileUpload(files);
        });
    }

    handleFileUpload(files) {
        const preview = document.getElementById('file-preview');
        const validFiles = files.filter(file => file.type.startsWith('image/'));

        if (validFiles.length === 0) {
            this.showNotification('Please select valid image files', 'error');
            return;
        }

        if (validFiles.length > 5) {
            this.showNotification('Maximum 5 screenshots allowed', 'error');
            return;
        }

        // Show file previews
        preview.innerHTML = '';
        validFiles.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.className = 'preview-image';
                img.alt = file.name;
                
                const container = document.createElement('div');
                container.className = 'preview-container';
                container.appendChild(img);
                
                const removeBtn = document.createElement('button');
                removeBtn.textContent = '×';
                removeBtn.className = 'remove-btn';
                removeBtn.onclick = () => container.remove();
                
                container.appendChild(removeBtn);
                preview.appendChild(container);
            };
            reader.readAsDataURL(file);
        });
    }

    setupStyleSelection() {
        const styleCards = document.querySelectorAll('.style-card');
        styleCards.forEach(card => {
            card.addEventListener('click', () => {
                // Remove active class from all cards
                styleCards.forEach(c => c.classList.remove('active'));
                // Add active class to clicked card
                card.classList.add('active');
                
                // Update hidden input
                const styleInput = document.getElementById('style-input');
                if (styleInput) {
                    styleInput.value = card.dataset.style;
                }
            });
        });
    }

    setupGenerationProcess() {
        // Initialize progress indicators
        this.generationSteps = [
            'Analyzing source website...',
            'Extracting content and structure...',
            'Applying selected template...',
            'Generating responsive design...',
            'Optimizing assets...',
            'Finalizing website...'
        ];
    }

    async handleGeneration() {
        const formData = new FormData(document.getElementById('generator-form'));
        const files = document.getElementById('screenshot-input').files;
        
        // Add files to form data
        Array.from(files).forEach(file => {
            formData.append('screenshots', file);
        });

        // Show generation modal
        this.showGenerationModal();

        try {
            const response = await fetch('/api/generate', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                this.updateGenerationProgress(100, 'Generation completed!');
                setTimeout(() => {
                    this.hideGenerationModal();
                    window.location.href = `/preview?id=${result.projectId}`;
                }, 2000);
            } else {
                this.showNotification(result.error || 'Generation failed', 'error');
                this.hideGenerationModal();
            }
        } catch (error) {
            console.error('Generation error:', error);
            this.showNotification('Generation failed. Please try again.', 'error');
            this.hideGenerationModal();
        }
    }

    showGenerationModal() {
        const modal = document.createElement('div');
        modal.className = 'generation-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="progress-container">
                    <div class="progress-bar">
                        <div class="progress-fill" id="progress-fill"></div>
                    </div>
                    <p id="progress-text">Initializing generation...</p>
                </div>
                <div class="generation-steps" id="generation-steps"></div>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Animate modal appearance
        anime({
            targets: modal,
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutQuart'
        });

        this.currentStep = 0;
        this.simulateGenerationProgress();
    }

    simulateGenerationProgress() {
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        const stepsContainer = document.getElementById('generation-steps');

        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 15 + 5;
            if (progress > 100) progress = 100;

            progressFill.style.width = `${progress}%`;

            if (this.currentStep < this.generationSteps.length && progress > (this.currentStep + 1) * (100 / this.generationSteps.length)) {
                const step = document.createElement('div');
                step.className = 'step completed';
                step.textContent = '✓ ' + this.generationSteps[this.currentStep];
                stepsContainer.appendChild(step);
                
                progressText.textContent = this.generationSteps[this.currentStep];
                this.currentStep++;
            }

            if (progress >= 100) {
                clearInterval(interval);
                progressText.textContent = 'Generation completed!';
            }
        }, 500);
    }

    hideGenerationModal() {
        const modal = document.querySelector('.generation-modal');
        if (modal) {
            anime({
                targets: modal,
                opacity: [1, 0],
                duration: 300,
                easing: 'easeOutQuart',
                complete: () => modal.remove()
            });
        }
    }

    updateGenerationProgress(percentage, message) {
        const progressFill = document.getElementById('progress-fill');
        const progressText = document.getElementById('progress-text');
        
        if (progressFill) {
            progressFill.style.width = `${percentage}%`;
        }
        if (progressText) {
            progressText.textContent = message;
        }
    }

    // Preview page initialization
    initPreview() {
        this.loadProjectPreview();
        this.setupDeviceToggles();
        this.setupCodeViewer();
        this.setupExportOptions();
    }

    async loadProjectPreview() {
        const urlParams = new URLSearchParams(window.location.search);
        const projectId = urlParams.get('id');

        if (!projectId) {
            this.showNotification('No project ID provided', 'error');
            return;
        }

        try {
            const response = await fetch(`/api/projects/${projectId}`);
            const result = await response.json();

            if (result.success) {
                this.displayProjectPreview(result.data);
            } else {
                this.showNotification(result.error || 'Failed to load project', 'error');
            }
        } catch (error) {
            console.error('Error loading project:', error);
            this.showNotification('Failed to load project', 'error');
        }
    }

    displayProjectPreview(project) {
        const iframe = document.getElementById('preview-iframe');
        const title = document.getElementById('project-title');
        const info = document.getElementById('project-info');

        if (title) title.textContent = project.name;
        if (info) {
            info.innerHTML = `
                <p><strong>Style:</strong> ${project.style}</p>
                <p><strong>Generated:</strong> ${new Date(project.generatedAt).toLocaleDateString()}</p>
                <p><strong>Status:</strong> ${project.status}</p>
            `;
        }

        if (iframe) {
            iframe.src = `/projects/${project.id}/index.html`;
        }

        // Load code files
        this.loadCodeFiles(project);
    }

    setupDeviceToggles() {
        const toggles = document.querySelectorAll('.device-toggle');
        const preview = document.getElementById('preview-iframe');

        toggles.forEach(toggle => {
            toggle.addEventListener('click', () => {
                // Remove active class from all toggles
                toggles.forEach(t => t.classList.remove('active'));
                // Add active class to clicked toggle
                toggle.classList.add('active');

                const device = toggle.dataset.device;
                this.updatePreviewSize(device, preview);
            });
        });
    }

    updatePreviewSize(device, iframe) {
        const sizes = {
            desktop: '100%',
            tablet: '768px',
            mobile: '375px'
        };

        if (iframe) {
            iframe.style.width = sizes[device] || '100%';
            iframe.style.maxWidth = sizes[device] || '100%';
        }
    }

    setupCodeViewer() {
        const tabs = document.querySelectorAll('.code-tab');
        const viewers = document.querySelectorAll('.code-viewer');

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const fileType = tab.dataset.file;
                
                // Update active tab
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');

                // Show corresponding viewer
                viewers.forEach(viewer => {
                    viewer.style.display = viewer.dataset.file === fileType ? 'block' : 'none';
                });
            });
        });
    }

    async loadCodeFiles(project) {
        const files = ['index.html', 'styles.css', 'script.js'];
        
        for (const file of files) {
            const viewer = document.querySelector(`[data-file="${file}"] .code-content`);
            if (viewer && project.files[file]) {
                viewer.textContent = project.files[file];
                this.highlightCode(viewer, file);
            }
        }
    }

    highlightCode(element, filename) {
        const language = filename.split('.').pop();
        element.className = `language-${language}`;
        
        // Simple syntax highlighting
        let code = element.textContent;
        
        if (language === 'html') {
            code = code.replace(/(&lt;\/?[^&gt;]+&gt;)/g, '<span class="tag">$1</span>');
        } else if (language === 'css') {
            code = code.replace(/([a-z-]+):/g, '<span class="property">$1</span>:');
            code = code.replace(/#[a-f0-9]{3,6}/g, '<span class="color">$&</span>');
        } else if (language === 'js') {
            code = code.replace(/(function|const|let|var|if|else|for|while)/g, '<span class="keyword">$1</span>');
            code = code.replace(/'[^']*'/g, '<span class="string">$&</span>');
        }
        
        element.innerHTML = code;
    }

    setupExportOptions() {
        const downloadBtn = document.getElementById('download-btn');
        const wordpressBtn = document.getElementById('wordpress-btn');

        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => {
                this.exportProject();
            });
        }

        if (wordpressBtn) {
            wordpressBtn.addEventListener('click', () => {
                this.exportToWordPress();
            });
        }
    }

    async exportProject() {
        const urlParams = new URLSearchParams(window.location.search);
        const projectId = urlParams.get('id');

        try {
            const response = await fetch(`/api/export/${projectId}`, {
                method: 'POST'
            });

            if (response.ok) {
                // Trigger download
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `cloneforge-project-${projectId}.zip`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);

                this.showNotification('Project exported successfully!', 'success');
            } else {
                this.showNotification('Export failed', 'error');
            }
        } catch (error) {
            console.error('Export error:', error);
            this.showNotification('Export failed', 'error');
        }
    }

    async exportToWordPress() {
        const urlParams = new URLSearchParams(window.location.search);
        const projectId = urlParams.get('id');

        try {
            const response = await fetch(`/api/wordpress-export/${projectId}`, {
                method: 'POST'
            });
            const result = await response.json();

            if (result.success) {
                this.showNotification('WordPress export created! Check the export panel.', 'success');
                this.displayWordPressExport(result.data);
            } else {
                this.showNotification('WordPress export failed', 'error');
            }
        } catch (error) {
            console.error('WordPress export error:', error);
            this.showNotification('WordPress export failed', 'error');
        }
    }

    displayWordPressExport(data) {
        const exportPanel = document.getElementById('wordpress-export');
        if (exportPanel) {
            exportPanel.innerHTML = `
                <h3>WordPress Export Ready</h3>
                <p><strong>Theme:</strong> ${data.manifest.name}</p>
                <p><strong>Files:</strong> ${Object.keys(data.files).length} files</p>
                <p><strong>Templates:</strong> ${Object.keys(data.templates).length} templates</p>
                <div class="export-instructions">
                    <h4>Installation Instructions:</h4>
                    <ol>
                        <li>Download the export package</li>
                        <li>Upload to WordPress via Appearance > Themes</li>
                        <li>Activate the theme</li>
                        <li>Import demo content if available</li>
                    </ol>
                </div>
            `;
            exportPanel.style.display = 'block';
        }
    }

    // Admin page initialization
    async initAdmin() {
        await this.loadProjects();
        this.setupProjectFilters();
        this.setupProjectActions();
    }

    async loadProjects() {
        try {
            const response = await fetch('/api/projects');
            const result = await response.json();

            if (result.success) {
                this.displayProjects(result.data);
            } else {
                this.showNotification('Failed to load projects', 'error');
            }
        } catch (error) {
            console.error('Error loading projects:', error);
            this.showNotification('Failed to load projects', 'error');
        }
    }

    displayProjects(projects) {
        const container = document.getElementById('projects-grid');
        if (!container) return;

        container.innerHTML = '';

        projects.forEach(project => {
            const projectCard = this.createProjectCard(project);
            container.appendChild(projectCard);
        });

        // Animate cards
        if (typeof anime !== 'undefined') {
            anime({
                targets: '.project-card',
                translateY: [50, 0],
                opacity: [0, 1],
                delay: anime.stagger(100),
                duration: 600,
                easing: 'easeOutQuart'
            });
        }
    }

    createProjectCard(project) {
        const card = document.createElement('div');
        card.className = 'project-card';
        card.innerHTML = `
            <div class="project-thumbnail">
                <img src="${project.thumbnail || '/resources/images/placeholder.jpg'}" alt="${project.name}">
                <div class="project-overlay">
                    <button class="view-btn" data-id="${project.id}">View</button>
                    <button class="edit-btn" data-id="${project.id}">Edit</button>
                    <button class="delete-btn" data-id="${project.id}">Delete</button>
                </div>
            </div>
            <div class="project-info">
                <h3>${project.name}</h3>
                <p class="project-style">${project.style}</p>
                <p class="project-date">${new Date(project.generatedAt).toLocaleDateString()}</p>
                <span class="project-status status-${project.status}">${project.status}</span>
            </div>
        `;

        return card;
    }

    setupProjectFilters() {
        const searchInput = document.getElementById('project-search');
        const styleFilter = document.getElementById('style-filter');
        const statusFilter = document.getElementById('status-filter');

        if (searchInput) {
            searchInput.addEventListener('input', () => {
                this.filterProjects();
            });
        }

        if (styleFilter) {
            styleFilter.addEventListener('change', () => {
                this.filterProjects();
            });
        }

        if (statusFilter) {
            statusFilter.addEventListener('change', () => {
                this.filterProjects();
            });
        }
    }

    filterProjects() {
        const searchTerm = document.getElementById('project-search')?.value.toLowerCase() || '';
        const styleFilter = document.getElementById('style-filter')?.value || '';
        const statusFilter = document.getElementById('status-filter')?.value || '';

        const projectCards = document.querySelectorAll('.project-card');
        
        projectCards.forEach(card => {
            const name = card.querySelector('h3').textContent.toLowerCase();
            const style = card.querySelector('.project-style').textContent;
            const status = card.querySelector('.project-status').textContent;

            const matchesSearch = name.includes(searchTerm);
            const matchesStyle = !styleFilter || style === styleFilter;
            const matchesStatus = !statusFilter || status === statusFilter;

            if (matchesSearch && matchesStyle && matchesStatus) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }

    setupProjectActions() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('view-btn')) {
                const projectId = e.target.dataset.id;
                window.location.href = `/preview?id=${projectId}`;
            }

            if (e.target.classList.contains('edit-btn')) {
                const projectId = e.target.dataset.id;
                this.editProject(projectId);
            }

            if (e.target.classList.contains('delete-btn')) {
                const projectId = e.target.dataset.id;
                this.deleteProject(projectId);
            }
        });
    }

    editProject(projectId) {
        this.showNotification('Edit functionality coming soon!', 'info');
    }

    async deleteProject(projectId) {
        if (!confirm('Are you sure you want to delete this project?')) {
            return;
        }

        try {
            const response = await fetch(`/api/projects/${projectId}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                this.showNotification('Project deleted successfully', 'success');
                this.loadProjects(); // Reload projects
            } else {
                this.showNotification('Failed to delete project', 'error');
            }
        } catch (error) {
            console.error('Delete error:', error);
            this.showNotification('Failed to delete project', 'error');
        }
    }

    // Utility methods
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        // Animate in
        anime({
            targets: notification,
            translateX: [300, 0],
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutQuart'
        });

        // Remove after 3 seconds
        setTimeout(() => {
            anime({
                targets: notification,
                translateX: [0, 300],
                opacity: [1, 0],
                duration: 300,
                easing: 'easeOutQuart',
                complete: () => notification.remove()
            });
        }, 3000);
    }

    // Image generation
    async generateImage(prompt, options = {}) {
        try {
            const response = await fetch('/api/images/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    prompt,
                    size: options.size || '1024x1024',
                    style: options.style || 'default'
                })
            });

            const result = await response.json();

            if (result.success) {
                return result.data;
            } else {
                throw new Error(result.error || 'Image generation failed');
            }
        } catch (error) {
            console.error('Image generation error:', error);
            throw error;
        }
    }
}

// Initialize CloneForge when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.cloneForge = new CloneForge();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CloneForge;
}