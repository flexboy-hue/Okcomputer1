# CloneForge - Full-Stack Website Cloning & Generation Platform

A comprehensive, self-contained web application for cloning, customizing, and generating websites with advanced AI-powered tools and modern design.

![CloneForge Hero](resources/images/hero-preview.jpg)

## 🚀 Features

### Core Functionality
- **Website Cloning**: Advanced algorithms to analyze and replicate any website structure
- **Template System**: Pre-built templates for Portfolio, E-commerce, Blog, and Landing pages
- **AI Image Generation**: Integrated image generation for custom graphics and assets
- **Responsive Design**: All generated websites are mobile-first and fully responsive
- **Multiple Export Options**: Download as static files, WordPress themes, or Elementor templates

### Design & User Experience
- **Dark Mode Interface**: Modern, premium dark theme optimized for extended use
- **Real-time Previews**: Live preview with device switching (Desktop/Tablet/Mobile)
- **Interactive Dashboard**: Comprehensive project management and analytics
- **Smooth Animations**: Powered by Anime.js and PIXI.js for engaging interactions
- **Progressive Enhancement**: Works with and without JavaScript

### Technical Features
- **Full-Stack Architecture**: Complete Node.js backend with SQLite database
- **RESTful API**: Well-documented API for all operations
- **File Upload System**: Drag-and-drop screenshot uploads with validation
- **Code Generation**: Dynamic HTML/CSS/JS generation based on templates
- **Export System**: Automated ZIP and WordPress theme creation

## 🛠️ Technology Stack

### Frontend
- **HTML5** - Semantic markup and accessibility
- **CSS3** - Grid, Flexbox, custom properties, animations
- **JavaScript ES6+** - Modern syntax, modules, async/await
- **Anime.js** - Smooth animations and transitions
- **PIXI.js** - Interactive graphics and particle effects
- **ECharts.js** - Data visualization and charts

### Backend
- **Node.js** - JavaScript runtime environment
- **Express.js** - Web framework and routing
- **SQLite3** - Lightweight, file-based database
- **Sequelize** - ORM for database operations
- **Multer** - File upload handling
- **Archiver** - ZIP file creation

### Development Tools
- **npm** - Package management
- **Nodemon** - Development server with auto-restart
- **ESLint** - Code linting and quality
- **Prettier** - Code formatting

## 📁 Project Structure

```
cloneforge/
├── index.html              # Landing page with hero and features
├── generator.html          # Website generation interface
├── preview.html            # Project preview and code viewer
├── admin.html              # Dashboard and project management
├── main.js                 # Core JavaScript functionality
├── server.js               # Node.js Express server
├── database.js             # SQLite database configuration
├── package.json            # Node.js dependencies and scripts
├── design.md               # Visual design system documentation
├── interaction.md          # User interaction specifications
├── outline.md              # Project structure overview
├── README.md               # This file
├── cloneforge.db           # SQLite database (created on first run)
├── resources/              # Static assets
│   ├── images/            # UI images and generated content
│   ├── templates/         # HTML/CSS templates
│   └── uploads/           # User uploaded files
├── projects/              # Generated project storage
│   ├── demo-portfolio/    # Sample portfolio project
│   ├── demo-ecommerce/    # Sample e-commerce project
│   └── [project-id]/      # Dynamic project folders
└── export/                # Export functionality
    ├── wordpress/         # WordPress export templates
    └── templates/         # Export template files
```

## 🚦 Quick Start

### Prerequisites
- **Node.js** (v16.0.0 or higher)
- **npm** (v7.0.0 or higher)
- **Modern web browser** (Chrome, Firefox, Safari, Edge)

### Installation

1. **Clone or download the project files**
   ```bash
   # If using git
   git clone [repository-url]
   cd cloneforge
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:3000`

### Available Scripts

```bash
# Start development server with auto-restart
npm run dev

# Start production server
npm start

# Initialize database with sample data
npm run init-db
```

## 📖 Usage Guide

### Creating Your First Website

1. **Navigate to the Generator**
   - Click "Start Creating" from the home page
   - Or go directly to `/generator`

2. **Configure Your Project**
   - **URL Input**: Enter a website URL to clone (optional)
   - **Screenshots**: Upload screenshots for reference (optional)
   - **Template Style**: Choose from Portfolio, E-commerce, Blog, or Landing
   - **Custom Instructions**: Add specific requirements in the notes field

3. **Generate Website**
   - Click "Generate Website" to start the process
   - Monitor progress with real-time updates
   - Generation typically takes 2-3 minutes

4. **Preview and Customize**
   - View your generated website in the preview page
   - Switch between Desktop, Tablet, and Mobile views
   - Examine the generated HTML/CSS/JS code

5. **Export Your Project**
   - Download as ZIP file for static hosting
   - Export as WordPress theme
   - Access generated files directly in the `projects/` folder

### Dashboard Management

1. **Access Dashboard**
   - Navigate to `/admin` for project management
   - View statistics and analytics

2. **Manage Projects**
   - Search and filter your projects
   - View project details and status
   - Edit, preview, or delete projects

3. **Monitor Analytics**
   - Track generation times and success rates
   - View most used templates and features
   - Monitor system performance

### Image Generation

1. **Access Image Generator**
   - Available in the generator page
   - Or through the dashboard tools menu

2. **Generate Images**
   - Enter descriptive prompts
   - Choose size and style options
   - Generate placeholder or custom images

3. **Use Generated Images**
   - Images are saved to `resources/images/`
   - Automatically integrated into website templates
   - Available for download and reuse

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
# Server Configuration
PORT=3000
NODE_ENV=development

# Database Configuration
DB_PATH=./cloneforge.db

# File Upload Limits
MAX_FILE_SIZE=10485760
UPLOAD_DIR=./resources/uploads

# Generation Settings
DEFAULT_STYLE=portfolio
GENERATION_TIMEOUT=180000
```

### Database Schema

The application uses SQLite with the following models:

- **Project**: Generated websites with metadata
- **Image**: Generated images with prompts and parameters
- **Template**: Template definitions and files
- **User**: User accounts (stub for future authentication)

### Customization

#### Adding New Templates

1. Create template files in `resources/templates/`
2. Update the `Template` model in `database.js`
3. Add template options to the generator interface
4. Update the generation logic in `server.js`

#### Styling Customization

- Modify CSS custom properties in `:root` for theme changes
- Update color variables for brand customization
- Adjust animation timings and effects in `main.js`

#### Feature Extensions

- Add new API endpoints in `server.js`
- Extend the database schema for additional features
- Integrate external services through API calls
- Add new export formats and options

## 📤 Export Options

### Static Files (ZIP)
- Complete HTML/CSS/JS bundle
- Optimized assets and images
- Ready for any web server
- Includes all dependencies

### WordPress Theme
- Elementor-compatible structure
- Custom theme files and templates
- Widget configurations
- Installation guide included

### Direct Access
- Generated files available in `projects/[id]/`
- Individual file access via API
- Real-time preview capabilities

## 🔒 Security Features

- **Input Validation**: All user inputs are validated and sanitized
- **File Upload Security**: Type and size restrictions on uploads
- **CORS Protection**: Configured for secure cross-origin requests
- **Rate Limiting**: API endpoints are rate-limited to prevent abuse
- **Helmet Security**: HTTP security headers with Helmet.js

## 🎨 Design System

CloneForge follows a comprehensive design system documented in `design.md`:

### Color Palette
- **Primary**: Deep space background with purple gradients
- **Accents**: Electric blue, success green, warning amber
- **Text**: Pure white primary, soft gray secondary

### Typography
- **Display Font**: Inter (bold, geometric)
- **Body Font**: Inter (clean, readable)
- **Code Font**: JetBrains Mono (developer-friendly)

### Visual Effects
- **Particle Backgrounds**: PIXI.js powered animations
- **Smooth Transitions**: Anime.js for micro-interactions
- **Data Visualization**: ECharts for analytics
- **Responsive Grid**: CSS Grid and Flexbox layouts

## 🧪 Testing

### Manual Testing
1. **Home Page**: Verify navigation, animations, and CTA buttons
2. **Generator**: Test form validation, file uploads, and generation process
3. **Preview**: Check device toggles, code viewer, and export functions
4. **Dashboard**: Test project management, search, and filtering
5. **API Endpoints**: Verify all API responses and error handling

### Automated Testing
```bash
# Run linting
npm run lint

# Check code formatting
npm run format:check
```

## 🐛 Troubleshooting

### Common Issues

**Port Already in Use**
```bash
# Change port in .env file or kill existing process
PORT=3001 npm run dev
```

**Database Errors**
```bash
# Reset database
rm cloneforge.db
npm run init-db
```

**File Upload Issues**
- Check file size limits (10MB default)
- Verify image file types (JPG, PNG, GIF, WebP)
- Ensure write permissions for upload directories

**Generation Failures**
- Check server logs for error messages
- Verify template files exist
- Ensure sufficient disk space

### Performance Optimization

- **Image Optimization**: Generated images are automatically optimized
- **Caching**: Static files are served with appropriate cache headers
- **Compression**: GZIP compression enabled for all responses
- **Database Indexing**: Optimized queries with proper indexing

## 📚 API Documentation

### Endpoints

#### Projects
- `GET /api/projects` - List all projects
- `GET /api/projects/:id` - Get specific project
- `POST /api/generate` - Create new project
- `DELETE /api/projects/:id` - Delete project

#### Templates
- `GET /api/templates` - List all templates

#### Images
- `POST /api/images/generate` - Generate image from prompt

#### Export
- `POST /api/export/:id` - Export project as ZIP
- `POST /api/wordpress-export/:id` - Export as WordPress theme

### Response Format

All API responses follow a consistent format:
```json
{
  "success": true,
  "message": "Operation completed",
  "data": { /* response data */ }
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

### Development Guidelines

- Follow the existing code style and conventions
- Add comments for complex logic
- Update documentation for new features
- Test on multiple browsers and devices
- Ensure accessibility compliance

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **Design Inspiration**: Modern web development tools and platforms
- **Animation Libraries**: Anime.js for smooth interactions
- **Graphics**: PIXI.js for hardware-accelerated visuals
- **Data Visualization**: ECharts for beautiful charts
- **Typography**: Inter font family for clean, modern text

## 📞 Support

For support and questions:
- Check the documentation in `docs/`
- Review the troubleshooting section
- Check existing issues and discussions
- Create a new issue for bugs or feature requests

---

**Built with ❤️ for web creators worldwide**

*CloneForge empowers developers, designers, and creators to build amazing websites with the power of modern web technologies and AI-assisted generation.*