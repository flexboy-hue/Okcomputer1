const { Sequelize, DataTypes } = require('sequelize');
const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// Initialize SQLite database
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, 'cloneforge.db'),
  logging: false
});

// Define Project model
const Project = sequelize.define('Project', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  sourceUrl: {
    type: DataTypes.STRING,
    allowNull: true
  },
  style: {
    type: DataTypes.ENUM('portfolio', 'ecommerce', 'blog', 'landing'),
    defaultValue: 'portfolio'
  },
  status: {
    type: DataTypes.ENUM('pending', 'generating', 'completed', 'failed'),
    defaultValue: 'pending'
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  files: {
    type: DataTypes.JSON,
    defaultValue: {}
  },
  thumbnail: {
    type: DataTypes.STRING,
    allowNull: true
  },
  generatedAt: {
    type: DataTypes.DATE,
    allowNull: true
  }
});

// Define User model (stub for future authentication)
const User = sequelize.define('User', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  username: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  email: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

// Define Image model for generated images
const Image = sequelize.define('Image', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  prompt: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  filename: {
    type: DataTypes.STRING,
    allowNull: false
  },
  size: {
    type: DataTypes.STRING,
    defaultValue: '1024x1024'
  },
  style: {
    type: DataTypes.STRING,
    allowNull: true
  },
  projectId: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: 'Projects',
      key: 'id'
    }
  }
});

// Define Template model
const Template = sequelize.define('Template', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  type: {
    type: DataTypes.ENUM('portfolio', 'ecommerce', 'blog', 'landing'),
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  files: {
    type: DataTypes.JSON,
    defaultValue: {}
  },
  preview: {
    type: DataTypes.STRING,
    allowNull: true
  }
});

// Define associations
Project.hasMany(Image, { foreignKey: 'projectId', as: 'images' });
Image.belongsTo(Project, { foreignKey: 'projectId', as: 'project' });

// Database initialization function
async function initializeDatabase() {
  try {
    // Sync all models
    await sequelize.sync({ force: true });
    console.log('Database synchronized successfully');

    // Create sample templates
    const templates = await Template.bulkCreate([
      {
        name: 'Modern Portfolio',
        type: 'portfolio',
        description: 'Clean and professional portfolio template for creative professionals',
        files: {
          'index.html': '<!DOCTYPE html>...',
          'styles.css': '/* Portfolio styles */',
          'script.js': '// Portfolio functionality'
        },
        preview: '/resources/templates/portfolio-preview.jpg'
      },
      {
        name: 'E-Commerce Store',
        type: 'ecommerce',
        description: 'Full-featured online store with product catalog and cart',
        files: {
          'index.html': '<!DOCTYPE html>...',
          'styles.css': '/* E-commerce styles */',
          'script.js': '// E-commerce functionality'
        },
        preview: '/resources/templates/ecommerce-preview.jpg'
      },
      {
        name: 'Personal Blog',
        type: 'blog',
        description: 'Elegant blog template with post management and categories',
        files: {
          'index.html': '<!DOCTYPE html>...',
          'styles.css': '/* Blog styles */',
          'script.js': '// Blog functionality'
        },
        preview: '/resources/templates/blog-preview.jpg'
      },
      {
        name: 'Landing Page',
        type: 'landing',
        description: 'High-converting landing page with lead capture forms',
        files: {
          'index.html': '<!DOCTYPE html>...',
          'styles.css': '/* Landing page styles */',
          'script.js': '// Landing page functionality'
        },
        preview: '/resources/templates/landing-preview.jpg'
      }
    ]);

    // Create sample projects
    const sampleProjects = await Project.bulkCreate([
      {
        id: '550e8400-e29b-41d4-a716-446655440001',
        name: 'Creative Portfolio Demo',
        sourceUrl: 'https://example-portfolio.com',
        style: 'portfolio',
        status: 'completed',
        notes: 'Modern portfolio for a graphic designer with dark theme',
        files: {
          'index.html': '<!DOCTYPE html>...',
          'styles.css': '/* Custom styles */',
          'script.js': '// Interactive features'
        },
        thumbnail: '/resources/samples/portfolio-thumb.jpg',
        generatedAt: new Date()
      },
      {
        id: '550e8400-e29b-41d4-a716-446655440002',
        name: 'Online Store Demo',
        sourceUrl: 'https://example-store.com',
        style: 'ecommerce',
        status: 'completed',
        notes: 'E-commerce site with product grid and shopping features',
        files: {
          'index.html': '<!DOCTYPE html>...',
          'styles.css': '/* Store styles */',
          'script.js': '// Shopping cart logic'
        },
        thumbnail: '/resources/samples/ecommerce-thumb.jpg',
        generatedAt: new Date()
      }
    ]);

    // Create sample images
    await Image.bulkCreate([
      {
        prompt: 'Modern abstract hero background with purple gradients',
        filename: 'hero-bg-1.jpg',
        size: '1536x1024',
        style: 'abstract',
        projectId: '550e8400-e29b-41d4-a716-446655440001'
      },
      {
        prompt: 'Professional headshot placeholder for portfolio',
        filename: 'profile-pic-1.jpg',
        size: '1024x1024',
        style: 'portrait',
        projectId: '550e8400-e29b-41d4-a716-446655440001'
      }
    ]);

    console.log('Sample data created successfully');
    console.log(`Created ${templates.length} templates`);
    console.log(`Created ${sampleProjects.length} sample projects`);

  } catch (error) {
    console.error('Database initialization error:', error);
  }
}

// Export models and database instance
module.exports = {
  sequelize,
  Project,
  User,
  Image,
  Template,
  initializeDatabase
};