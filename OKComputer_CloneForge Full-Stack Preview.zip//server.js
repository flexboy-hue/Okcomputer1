const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { v4: uuidv4 } = require('uuid');
const archiver = require('archiver');

const { sequelize, Project, Image, Template, initializeDatabase } = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'self'"]
    }
  }
}));

// CORS configuration
app.use(cors({
  origin: true,
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use('/api/', limiter);

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static file serving
app.use(express.static(path.join(__dirname)));
app.use('/resources', express.static(path.join(__dirname, 'resources')));
app.use('/projects', express.static(path.join(__dirname, 'projects')));

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, 'resources', 'uploads');
    fs.ensureDirSync(uploadPath);
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}-${file.originalname}`;
    cb(null, uniqueName);
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// API Routes

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// Get all projects
app.get('/api/projects', async (req, res) => {
  try {
    const projects = await Project.findAll({
      include: [{
        model: Image,
        as: 'images'
      }],
      order: [['createdAt', 'DESC']]
    });
    
    res.json({
      success: true,
      count: projects.length,
      data: projects
    });
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch projects'
    });
  }
});

// Get single project
app.get('/api/projects/:id', async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id, {
      include: [{
        model: Image,
        as: 'images'
      }]
    });
    
    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    res.json({
      success: true,
      data: project
    });
  } catch (error) {
    console.error('Error fetching project:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch project'
    });
  }
});

// Get all templates
app.get('/api/templates', async (req, res) => {
  try {
    const templates = await Template.findAll();
    res.json({
      success: true,
      count: templates.length,
      data: templates
    });
  } catch (error) {
    console.error('Error fetching templates:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch templates'
    });
  }
});

// Generate website
app.post('/api/generate', upload.array('screenshots', 5), async (req, res) => {
  try {
    const { url, style, notes } = req.body;
    
    // Validate input
    if (!url && !req.files.length) {
      return res.status(400).json({
        success: false,
        error: 'Either URL or screenshots are required'
      });
    }
    
    // Create project record
    const project = await Project.create({
      name: `Generated ${style} site`,
      sourceUrl: url || null,
      style: style || 'portfolio',
      notes: notes || '',
      status: 'generating'
    });
    
    // Create project directory
    const projectDir = path.join(__dirname, 'projects', project.id);
    await fs.ensureDir(projectDir);
    
    // Simulate generation process
    setTimeout(async () => {
      try {
        // Generate HTML based on template
        const html = generateHTML(style, project);
        const css = generateCSS(style);
        const js = generateJS(style);
        
        // Write files
        await fs.writeFile(path.join(projectDir, 'index.html'), html);
        await fs.writeFile(path.join(projectDir, 'styles.css'), css);
        await fs.writeFile(path.join(projectDir, 'script.js'), js);
        
        // Update project status
        await project.update({
          status: 'completed',
          files: {
            'index.html': html,
            'styles.css': css,
            'script.js': js
          },
          generatedAt: new Date()
        });
        
        console.log(`Project ${project.id} generated successfully`);
      } catch (error) {
        console.error('Generation error:', error);
        await project.update({ status: 'failed' });
      }
    }, 3000); // Simulate 3-second generation
    
    res.json({
      success: true,
      message: 'Generation started',
      projectId: project.id
    });
    
  } catch (error) {
    console.error('Error in generation:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to start generation'
    });
  }
});

// Generate preview
app.post('/api/preview/:id', async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id);
    
    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    res.json({
      success: true,
      data: {
        projectId: project.id,
        files: project.files,
        previewUrl: `/projects/${project.id}/index.html`
      }
    });
  } catch (error) {
    console.error('Error generating preview:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate preview'
    });
  }
});

// Export project
app.post('/api/export/:id', async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id);
    
    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    const projectDir = path.join(__dirname, 'projects', project.id);
    const zipPath = path.join(__dirname, 'projects', `${project.id}.zip`);
    
    // Create ZIP archive
    const output = fs.createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });
    
    output.on('close', () => {
      res.download(zipPath, `${project.name.replace(/\s+/g, '_')}.zip`, (err) => {
        if (err) {
          console.error('Download error:', err);
        }
        // Clean up zip file after download
        fs.remove(zipPath).catch(console.error);
      });
    });
    
    archive.on('error', (err) => {
      throw err;
    });
    
    archive.pipe(output);
    archive.directory(projectDir, false);
    await archive.finalize();
    
  } catch (error) {
    console.error('Error exporting project:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to export project'
    });
  }
});

// Generate image
app.post('/api/images/generate', async (req, res) => {
  try {
    const { prompt, size = '1024x1024', style } = req.body;
    
    if (!prompt) {
      return res.status(400).json({
        success: false,
        error: 'Prompt is required'
      });
    }
    
    // Generate image filename
    const imageId = uuidv4();
    const filename = `generated-${imageId}.jpg`;
    const imagePath = path.join(__dirname, 'resources', 'images', filename);
    
    // Ensure images directory exists
    await fs.ensureDir(path.dirname(imagePath));
    
    // Create a placeholder image (in a real implementation, this would call an AI service)
    const generatedImage = await generatePlaceholderImage(prompt, size, style);
    
    // Save image
    await fs.writeFile(imagePath, generatedImage);
    
    // Save to database
    const image = await Image.create({
      prompt,
      filename,
      size,
      style: style || 'default'
    });
    
    res.json({
      success: true,
      data: {
        id: image.id,
        filename,
        url: `/resources/images/${filename}`,
        prompt: image.prompt
      }
    });
    
  } catch (error) {
    console.error('Error generating image:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate image'
    });
  }
});

// WordPress export stub
app.post('/api/wordpress-export/:id', async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id);
    
    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    // Create WordPress export structure
    const wpExport = createWordPressExport(project);
    
    res.json({
      success: true,
      message: 'WordPress export created',
      data: wpExport
    });
    
  } catch (error) {
    console.error('Error creating WordPress export:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create WordPress export'
    });
  }
});

// Helper functions

function generateHTML(style, project) {
  const templates = {
    portfolio: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${project.name}</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Portfolio</div>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#work">Work</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section id="home" class="hero">
            <div class="hero-content">
                <h1>Welcome to My Portfolio</h1>
                <p>Creative solutions for modern challenges</p>
                <button class="cta">View My Work</button>
            </div>
        </section>
        
        <section id="about" class="about">
            <div class="container">
                <h2>About Me</h2>
                <p>Passionate creator with expertise in design and development.</p>
            </div>
        </section>
        
        <section id="work" class="work">
            <div class="container">
                <h2>My Work</h2>
                <div class="project-grid">
                    <div class="project-card">
                        <h3>Project One</h3>
                        <p>Description of your amazing project</p>
                    </div>
                    <div class="project-card">
                        <h3>Project Two</h3>
                        <p>Another fantastic creation</p>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="contact" class="contact">
            <div class="container">
                <h2>Get In Touch</h2>
                <form>
                    <input type="text" placeholder="Your Name" required>
                    <input type="email" placeholder="Your Email" required>
                    <textarea placeholder="Your Message" required></textarea>
                    <button type="submit">Send Message</button>
                </form>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2024 ${project.name}. All rights reserved.</p>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>`,
    
    ecommerce: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${project.name}</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Store</div>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#products">Products</a></li>
                <li><a href="#cart">Cart</a></li>
                <li><a href="#account">Account</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section id="home" class="hero">
            <div class="hero-content">
                <h1>Welcome to Our Store</h1>
                <p>Discover amazing products at great prices</p>
                <button class="cta">Shop Now</button>
            </div>
        </section>
        
        <section id="products" class="products">
            <div class="container">
                <h2>Featured Products</h2>
                <div class="product-grid">
                    <div class="product-card">
                        <h3>Product One</h3>
                        <p class="price">$29.99</p>
                        <button>Add to Cart</button>
                    </div>
                    <div class="product-card">
                        <h3>Product Two</h3>
                        <p class="price">$39.99</p>
                        <button>Add to Cart</button>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2024 ${project.name}. All rights reserved.</p>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>`,
    
    blog: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${project.name}</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Blog</div>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#articles">Articles</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section id="home" class="hero">
            <div class="hero-content">
                <h1>Welcome to My Blog</h1>
                <p>Thoughts, stories and ideas</p>
                <button class="cta">Read Latest</button>
            </div>
        </section>
        
        <section id="articles" class="articles">
            <div class="container">
                <h2>Latest Articles</h2>
                <div class="article-list">
                    <article class="article-card">
                        <h3>Article Title One</h3>
                        <p class="excerpt">This is a summary of your first blog post...</p>
                        <a href="#" class="read-more">Read More</a>
                    </article>
                    <article class="article-card">
                        <h3>Article Title Two</h3>
                        <p class="excerpt">This is a summary of your second blog post...</p>
                        <a href="#" class="read-more">Read More</a>
                    </article>
                </div>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2024 ${project.name}. All rights reserved.</p>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>`,
    
    landing: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${project.name}</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Brand</div>
            <ul>
                <li><a href="#features">Features</a></li>
                <li><a href="#pricing">Pricing</a></li>
                <li><a href="#testimonials">Reviews</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section id="home" class="hero">
            <div class="hero-content">
                <h1>Transform Your Business</h1>
                <p>Powerful solutions for modern companies</p>
                <button class="cta">Get Started Today</button>
            </div>
        </section>
        
        <section id="features" class="features">
            <div class="container">
                <h2>Why Choose Us</h2>
                <div class="feature-grid">
                    <div class="feature-card">
                        <h3>Feature One</h3>
                        <p>Amazing benefit description</p>
                    </div>
                    <div class="feature-card">
                        <h3>Feature Two</h3>
                        <p>Another great benefit</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2024 ${project.name}. All rights reserved.</p>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>`
  };
  
  return templates[style] || templates.portfolio;
}

function generateCSS(style) {
  const baseCSS = `
/* Reset and base styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: #ffffff;
    background: linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 100%);
    min-height: 100vh;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Header */
header {
    background: rgba(10, 10, 15, 0.9);
    backdrop-filter: blur(10px);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    border-bottom: 1px solid rgba(99, 102, 241, 0.2);
}

nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 2rem;
    max-width: 1200px;
    margin: 0 auto;
}

.logo {
    font-size: 1.5rem;
    font-weight: bold;
    background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

nav ul {
    display: flex;
    list-style: none;
    gap: 2rem;
}

nav a {
    color: #ffffff;
    text-decoration: none;
    transition: color 0.3s ease;
}

nav a:hover {
    color: #6366f1;
}

/* Hero section */
.hero {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    background: linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #16213e 100%);
    position: relative;
    overflow: hidden;
}

.hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at 30% 50%, rgba(99, 102, 241, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 70% 80%, rgba(139, 92, 246, 0.1) 0%, transparent 50%);
    pointer-events: none;
}

.hero-content {
    position: relative;
    z-index: 1;
    max-width: 800px;
    padding: 0 2rem;
}

.hero h1 {
    font-size: 3.5rem;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #ffffff 0%, #6366f1 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1.2;
}

.hero p {
    font-size: 1.25rem;
    margin-bottom: 2rem;
    color: #a1a1aa;
}

.cta {
    background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
    color: white;
    border: none;
    padding: 1rem 2rem;
    font-size: 1.1rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);
}

.cta:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(99, 102, 241, 0.4);
}

/* Main content */
main {
    padding-top: 80px;
}

section {
    padding: 4rem 0;
}

section h2 {
    font-size: 2.5rem;
    margin-bottom: 2rem;
    text-align: center;
    background: linear-gradient(135deg, #ffffff 0%, #6366f1 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* Grid layouts */
.project-grid,
.product-grid,
.feature-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.project-card,
.product-card,
.feature-card {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(99, 102, 241, 0.2);
    border-radius: 12px;
    padding: 2rem;
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
}

.project-card:hover,
.product-card:hover,
.feature-card:hover {
    transform: translateY(-5px);
    border-color: rgba(99, 102, 241, 0.5);
    box-shadow: 0 10px 30px rgba(99, 102, 241, 0.2);
}

/* Forms */
form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
    max-width: 500px;
    margin: 0 auto;
}

input,
textarea {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(99, 102, 241, 0.3);
    border-radius: 8px;
    padding: 1rem;
    color: white;
    font-size: 1rem;
    transition: border-color 0.3s ease;
}

input:focus,
textarea:focus {
    outline: none;
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
}

textarea {
    min-height: 120px;
    resize: vertical;
}

/* Footer */
footer {
    background: rgba(10, 10, 15, 0.9);
    text-align: center;
    padding: 2rem;
    border-top: 1px solid rgba(99, 102, 241, 0.2);
}

/* Responsive */
@media (max-width: 768px) {
    .hero h1 {
        font-size: 2.5rem;
    }
    
    nav {
        padding: 1rem;
    }
    
    nav ul {
        gap: 1rem;
    }
    
    .project-grid,
    .product-grid,
    .feature-grid {
        grid-template-columns: 1fr;
    }
}`;
  
  return baseCSS;
}

function generateJS(style) {
  const baseJS = `
// Smooth scrolling for navigation links
document.addEventListener('DOMContentLoaded', function() {
    // Smooth scroll
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Form submission
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Thank you! Your message has been sent.');
            form.reset();
        });
    });
    
    // Button interactions
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            if (this.textContent.includes('Cart')) {
                alert('Item added to cart!');
            } else if (this.textContent.includes('Get Started') || this.textContent.includes('Shop Now') || this.textContent.includes('View My Work')) {
                alert('Feature coming soon!');
            }
        });
    });
    
    // Add scroll effect to header
    let lastScroll = 0;
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        const header = document.querySelector('header');
        
        if (currentScroll > 100) {
            header.style.background = 'rgba(10, 10, 15, 0.95)';
        } else {
            header.style.background = 'rgba(10, 10, 15, 0.9)';
        }
        
        lastScroll = currentScroll;
    });
    
    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe all cards
    const cards = document.querySelectorAll('.project-card, .product-card, .feature-card, .article-card');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
});
`;
  
  return baseJS;
}

async function generatePlaceholderImage(prompt, size, style) {
  // In a real implementation, this would call an AI image generation service
  // For now, we'll create a simple SVG placeholder
  const [width, height] = size.split('x').map(Number);
  
  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#6366f1;stop-opacity:1" />
          <stop offset="100%" style="stop-color:#8b5cf6;stop-opacity:1" />
        </linearGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#grad)" />
      <text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="white" font-family="Arial, sans-serif" font-size="24">
        ${prompt.substring(0, 50)}...
      </text>
      <text x="50%" y="60%" text-anchor="middle" dy=".3em" fill="white" font-family="Arial, sans-serif" font-size="16">
        ${size} • ${style || 'default'}
      </text>
    </svg>
  `;
  
  return Buffer.from(svg);
}

function createWordPressExport(project) {
  // Create WordPress export structure
  return {
    manifest: {
      name: project.name,
      version: '1.0.0',
      type: 'wordpress-theme',
      created: new Date().toISOString()
    },
    files: {
      'style.css': `/*\nTheme Name: ${project.name}\nDescription: Generated by CloneForge\nVersion: 1.0.0\n*/`,
      'index.php': '<?php get_header(); ?>\n<!-- WordPress loop -->\n<?php get_footer(); ?>',
      'functions.php': '<?php\n// Theme functions\nadd_theme_support(\'post-thumbnails\');\n?>'
    },
    templates: {
      page: 'page.php',
      single: 'single.php',
      archive: 'archive.php'
    },
    widgets: [
      'sidebar-1',
      'footer-1'
    ]
  };
}

// Serve HTML pages
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/generator', (req, res) => {
  res.sendFile(path.join(__dirname, 'generator.html'));
});

app.get('/preview', (req, res) => {
  res.sendFile(path.join(__dirname, 'preview.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({
    success: false,
    error: 'Internal server error'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint not found'
  });
});

// Initialize database and start server
async function startServer() {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`CloneForge server running on port ${PORT}`);
      console.log(`Access the application at: http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();