# CloneForge Design System

## Design Philosophy

CloneForge embodies a modern, premium aesthetic that balances technical sophistication with approachable usability. The design language draws inspiration from contemporary developer tools and design platforms, creating an environment that feels both professional and inspiring.

### Core Principles
- **Dark Mode First**: Optimized for extended use with reduced eye strain
- **Premium Feel**: High-contrast elements with subtle luxury touches
- **Technical Elegance**: Clean, grid-based layouts that showcase functionality
- **Smooth Interactions**: Micro-animations that provide feedback and delight
- **Mobile-Responsive**: Seamless experience across all device sizes

## Color Palette

### Primary Colors
- **Deep Space**: `#0a0a0f` (Main background)
- **Void Black**: `#000000` (Darker accents)
- **Pure White**: `#ffffff` (Primary text)
- **Soft Gray**: `#a1a1aa` (Secondary text)

### Accent Colors
- **Purple Gradient**: `#6366f1` → `#8b5cf6` (Primary actions, highlights)
- **Indigo Gradient**: `#4f46e5` → `#7c3aed` (Secondary actions, borders)
- **Electric Blue**: `#06b6d4` (Status indicators, links)
- **Success Green**: `#10b981` (Success states)
- **Warning Amber**: `#f59e0b` (Warnings)
- **Error Red**: `#ef4444` (Error states)

## Typography

### Font Families
- **Display Font**: "Inter" - Modern, geometric sans-serif for headings
- **Body Font**: "Inter" - Consistent with display for optimal readability
- **Code Font**: "JetBrains Mono" - For code snippets and technical content

### Type Scale
- **Hero**: 3.5rem (56px) - Main page titles
- **H1**: 2.5rem (40px) - Section headers
- **H2**: 2rem (32px) - Subsection headers
- **H3**: 1.5rem (24px) - Component titles
- **Body**: 1rem (16px) - Standard text
- **Small**: 0.875rem (14px) - Captions, metadata
- **Tiny**: 0.75rem (12px) - Labels, fine print

## Visual Effects

### Used Libraries
- **Anime.js**: Smooth micro-animations and transitions
- **Shader-park**: Background visual effects
- **PIXI.js**: Interactive particle systems
- **ECharts.js**: Data visualization
- **Splide.js**: Image carousels and sliders
- **p5.js**: Creative coding elements

### Effect Applications
- **Hero Background**: Animated gradient flow with particle system
- **Button Interactions**: Subtle scale and glow effects
- **Card Hover**: 3D tilt with shadow expansion
- **Loading States**: Smooth progress indicators with particle trails
- **Scroll Animations**: Gentle fade-in with staggered timing
- **Form Focus**: Glowing border transitions

### Animation Principles
- **Duration**: 150-300ms for micro-interactions
- **Easing**: Cubic-bezier curves for natural motion
- **Stagger**: 50ms delays between grouped elements
- **Feedback**: Immediate visual response to user actions

## Layout System

### Grid Structure
- **Desktop**: 12-column grid with 24px gutters
- **Tablet**: 8-column grid with 20px gutters  
- **Mobile**: 4-column grid with 16px gutters

### Spacing Scale
- **xs**: 4px - Tight spacing
- **sm**: 8px - Component internal spacing
- **md**: 16px - Standard spacing
- **lg**: 24px - Section spacing
- **xl**: 48px - Major section breaks
- **2xl**: 96px - Page section dividers

### Component Hierarchy
- **Navigation**: Fixed header with blur backdrop
- **Hero**: Full-width with centered content
- **Content**: Max-width containers with proper padding
- **Footer**: Minimal, copyright-only design

## Interactive Elements

### Button Styles
- **Primary**: Purple gradient with white text, hover glow
- **Secondary**: Transparent with purple border, hover fill
- **Ghost**: Text-only with subtle background on hover
- **Danger**: Red gradient for destructive actions

### Form Elements
- **Input Fields**: Dark background with purple focus border
- **Dropdowns**: Custom styled with smooth open/close
- **Checkboxes**: Custom purple checkmarks
- **Radio Buttons**: Purple filled circles

### Card Design
- **Background**: Slightly lighter than main background
- **Border**: Subtle purple tint
- **Shadow**: Multi-layered for depth
- **Hover**: Lift effect with increased shadow

This design system ensures CloneForge maintains a cohesive, premium appearance while providing excellent usability across all features and interactions.