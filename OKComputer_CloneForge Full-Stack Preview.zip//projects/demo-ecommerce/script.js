// E-commerce functionality
document.addEventListener('DOMContentLoaded', function() {
    let cart = [];
    
    // Smooth scrolling for navigation links
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            const productName = productCard.querySelector('h3').textContent;
            const productPrice = productCard.querySelector('.current-price').textContent;
            
            // Add to cart array
            cart.push({
                name: productName,
                price: productPrice,
                id: Date.now()
            });
            
            // Update cart count
            updateCartCount();
            
            // Show feedback
            this.textContent = 'Added!';
            this.style.background = '#10b981';
            
            setTimeout(() => {
                this.textContent = 'Add to Cart';
                this.style.background = 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)';
            }, 1000);
            
            // Show notification
            showNotification(`${productName} added to cart!`);
        });
    });
    
    // Category button functionality
    const categoryButtons = document.querySelectorAll('.category-btn');
    categoryButtons.forEach(button => {
        button.addEventListener('click', function() {
            const categoryCard = this.closest('.category-card');
            const categoryName = categoryCard.querySelector('h3').textContent;
            
            // Simulate category navigation
            showNotification(`Opening ${categoryName} category...`);
            
            // Add loading effect
            this.textContent = 'Loading...';
            this.disabled = true;
            
            setTimeout(() => {
                this.textContent = 'Shop Now';
                this.disabled = false;
                showNotification(`${categoryName} category coming soon!`);
            }, 1500);
        });
    });
    
    // CTA button functionality
    const ctaButton = document.querySelector('.cta');
    if (ctaButton) {
        ctaButton.addEventListener('click', function() {
            document.getElementById('products').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    }
    
    // Cart icon click
    const cartIcon = document.querySelector('.cart-icon');
    if (cartIcon) {
        cartIcon.addEventListener('click', function() {
            if (cart.length === 0) {
                showNotification('Your cart is empty');
            } else {
                showCartContents();
            }
        });
    }
    
    // Update cart count
    function updateCartCount() {
        const cartCount = document.querySelector('.cart-count');
        if (cartCount) {
            cartCount.textContent = cart.length;
            
            // Add animation
            cartCount.style.transform = 'scale(1.3)';
            setTimeout(() => {
                cartCount.style.transform = 'scale(1)';
            }, 200);
        }
    }
    
    // Show cart contents
    function showCartContents() {
        let cartMessage = `Cart Contents (${cart.length} items):\n\n`;
        let total = 0;
        
        cart.forEach((item, index) => {
            const price = parseFloat(item.price.replace('$', ''));
            total += price;
            cartMessage += `${index + 1}. ${item.name} - ${item.price}\n`;
        });
        
        cartMessage += `\nTotal: $${total.toFixed(2)}\n\n`;
        cartMessage += 'Checkout functionality coming soon!';
        
        alert(cartMessage);
    }
    
    // Show notification
    function showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 24px;
            background: rgba(99, 102, 241, 0.95);
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            z-index: 10000;
            max-width: 300px;
            backdrop-filter: blur(10px);
            font-size: 0.9rem;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
            transform: translateX(100%);
            transition: transform 0.3s ease;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    // Add scroll effect to header
    let lastScroll = 0;
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        const header = document.querySelector('header');
        
        if (currentScroll > 100) {
            header.style.background = 'rgba(10, 10, 15, 0.95)';
        } else {
            header.style.background = 'rgba(10, 10, 15, 0.9)';
        }
        
        lastScroll = currentScroll;
    });
    
    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe all product cards and category cards
    const cards = document.querySelectorAll('.product-card, .category-card, .feature');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
    
    // Product search functionality (basic)
    let searchTimeout;
    function setupSearch() {
        const searchInput = document.createElement('input');
        searchInput.type = 'text';
        searchInput.placeholder = 'Search products...';
        searchInput.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            background: rgba(10, 10, 15, 0.9);
            border: 1px solid rgba(99, 102, 241, 0.3);
            border-radius: 6px;
            padding: 8px 12px;
            color: white;
            font-size: 0.9rem;
            width: 200px;
            z-index: 999;
            backdrop-filter: blur(10px);
        `;
        
        searchInput.addEventListener('input', function(e) {
            clearTimeout(searchTimeout);
            const searchTerm = e.target.value.toLowerCase();
            
            searchTimeout = setTimeout(() => {
                const products = document.querySelectorAll('.product-card');
                products.forEach(product => {
                    const productName = product.querySelector('h3').textContent.toLowerCase();
                    const productDescription = product.querySelector('.product-description').textContent.toLowerCase();
                    
                    if (productName.includes(searchTerm) || productDescription.includes(searchTerm)) {
                        product.style.display = 'block';
                        product.style.opacity = '1';
                    } else if (searchTerm.length > 0) {
                        product.style.opacity = '0.3';
                    } else {
                        product.style.opacity = '1';
                    }
                });
            }, 300);
        });
        
        document.body.appendChild(searchInput);
    }
    
    // Add search functionality (commented out by default)
    // setupSearch();
});